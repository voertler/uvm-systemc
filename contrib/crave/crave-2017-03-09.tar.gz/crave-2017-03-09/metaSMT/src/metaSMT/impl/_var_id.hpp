#pragma once

namespace metaSMT {
  namespace impl {
      unsigned new_var_id();
  } /* impl */
} /* metaSMT */
