#pragma once
#include <boost/mpl/map/map50.hpp>
namespace boost { namespace mpl {
#define BOOST_PP_ITERATION_PARAMS_1 \
    (3, (51, 60, "boost/mpl/map/aux_/numbered.hpp"))
#include BOOST_PP_ITERATE()
}}
