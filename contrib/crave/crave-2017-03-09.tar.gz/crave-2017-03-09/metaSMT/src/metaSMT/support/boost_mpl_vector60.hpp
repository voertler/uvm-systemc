#pragma once
#include <boost/mpl/vector/vector50.hpp>
namespace boost { namespace mpl {
#define BOOST_PP_ITERATION_PARAMS_1 \
    (3, (51, 60, "boost/mpl/vector/aux_/numbered.hpp"))
#include BOOST_PP_ITERATE()
}}
