#include "common.hpp"

int main(int argc, char* argv[]) {
  run_test<false, true>();
  return 0;
}
