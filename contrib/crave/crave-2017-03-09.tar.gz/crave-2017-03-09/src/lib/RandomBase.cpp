// Copyright 2012-2016 The CRAVE developers, University of Bremen, Germany. All rights reserved.//
#include "../crave/frontend/RandomBase.hpp"

namespace crave {
std::map<int, __rand_vec_base*> vectorBaseMap;
}