// Copyright 2012-2016 The CRAVE developers, University of Bremen, Germany. All rights reserved.//

#pragma once

#include "SettingsType.hpp"
#include "CraveSettings.hpp"

namespace crave {}  // end namespace crave
