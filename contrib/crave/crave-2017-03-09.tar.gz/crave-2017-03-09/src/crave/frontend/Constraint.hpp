// Copyright 2012-2017 The CRAVE developers, University of Bremen, Germany. All rights reserved.

#pragma once

#include "ConstraintType.hpp"
#include "Operators.hpp"
#include "PlaceHolder.hpp"
#include "ReadReference.hpp"
#include "Variable.hpp"
#include "VectorConstraint.hpp"
#include "WriteReference.hpp"
