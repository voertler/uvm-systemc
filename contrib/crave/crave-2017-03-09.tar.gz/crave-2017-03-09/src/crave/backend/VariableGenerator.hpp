// Copyright 2012-2016 The CRAVE developers, University of Bremen, Germany. All rights reserved.//

#pragma once

#include "VariableSolver.hpp"
#include "VariableDefaultSolver.hpp"
#include "VariableCoverageSolver.hpp"
#include "VariableGeneratorType.hpp"
#include "VariableGeneratorMT.hpp"
#include "VariableCoverageGenerator.hpp"
#include "FactoryMetaSMT.hpp"
