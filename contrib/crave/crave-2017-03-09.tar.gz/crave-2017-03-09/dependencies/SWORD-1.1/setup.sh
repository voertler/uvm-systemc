#!/bin/sh

version=1.1

cmake_files_dir=$base_dir/SWORD-1.1

source $base_dir/SWORD-1.1/shared.sh

# vim: ts=2 sw=2 et