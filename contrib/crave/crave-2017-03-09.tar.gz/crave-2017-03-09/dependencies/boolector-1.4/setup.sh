#!/bin/sh

version=1.4
extra_ver=ffc2089-100608

dependencies="picosat-936"

patches_dir=$base_dir/boolector-1.4
cmake_files_dir=$base_dir/boolector-1.4

source $base_dir/boolector-1.4/shared.sh

# vim: te= sw=2 et
