#!/bin/sh

version=2.8.4

source $base_dir/cmake-2.8.4/shared.sh

# vim: ts=2 sw=2 et
