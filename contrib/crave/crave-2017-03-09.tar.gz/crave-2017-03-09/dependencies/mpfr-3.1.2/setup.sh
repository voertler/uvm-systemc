#!/bin/sh

version="3.1.2"
version_gmp="5.0.5"

source $base_dir/mpfr-3.1.2/shared.sh
