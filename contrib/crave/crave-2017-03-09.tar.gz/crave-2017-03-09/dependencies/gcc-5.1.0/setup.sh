#!/bin/sh

version="5.1.0"

version_gmp="4.3.2"
version_mpfr="2.4.2"
version_mpc="0.8.1"

source $base_dir/gcc-4.8.1/shared.sh
