#!/bin/sh

version="0.9"

version_gmp="5.0.5"
version_mpfr="3.1.2"

source $base_dir/mpc-0.9/shared.sh
