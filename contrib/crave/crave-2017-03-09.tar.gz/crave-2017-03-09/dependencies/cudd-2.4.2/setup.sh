#!/bin/sh

version=2.4.2

cmake_files_dir=$base_dir/cudd-2.4.2

source $base_dir/cudd-2.4.2/shared.sh

# vim: ts=2 sw=2 et
