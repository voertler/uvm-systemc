#!/bin/sh

version=2007.3.12

patches_dir=$base_dir/zchaff-2007.3.12
cmake_files_dir=$base_dir/zchaff-2007.3.12

source $base_dir/zchaff-2007.3.12/shared.sh

# vim: ts=2 sw=2 et
