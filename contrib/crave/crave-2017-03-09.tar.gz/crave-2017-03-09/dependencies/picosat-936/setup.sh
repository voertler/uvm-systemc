#!/bin/sh

version=936

cmake_files_dir=$base_dir/picosat-936

source $base_dir/picosat-936/shared.sh
