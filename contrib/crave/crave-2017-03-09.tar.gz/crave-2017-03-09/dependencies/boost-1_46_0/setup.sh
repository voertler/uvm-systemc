#!/bin/sh

version=1_46_0

source "$base_dir/boost-1_46_0/shared.sh"

# vim: ts=2 sw=2 et