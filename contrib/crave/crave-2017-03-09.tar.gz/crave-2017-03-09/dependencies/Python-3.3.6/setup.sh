#!/bin/sh

version=3.3.6

source "$base_dir/Python-2.7.10/shared.sh"

# vim: ts=2 sw=2 et
