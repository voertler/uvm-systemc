#!/bin/sh

version=git
branch=master

cmake_files_dir=$base_dir/Z3-git

source $base_dir/Z3-git/shared.sh
