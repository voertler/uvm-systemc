#!/bin/sh

version=5.0.5

source $base_dir/gmp-5.0.5/shared.sh

# vim: ts=2 sw=2 et
