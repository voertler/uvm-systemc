#!/bin/sh

version="1.4"
source $base_dir/cvc4-1.4/shared.sh
