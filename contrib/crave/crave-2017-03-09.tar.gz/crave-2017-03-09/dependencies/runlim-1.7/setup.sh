#!/bin/sh

version=1.7

source $base_dir/runlim-1.7/shared.sh

# vim: ts=2 sw=2 et

