#!/bin/sh

version=bal-2293bef-151129

cmake_files_dir=$base_dir/lingeling-${version}

source $base_dir/lingeling-${version}/shared.sh
