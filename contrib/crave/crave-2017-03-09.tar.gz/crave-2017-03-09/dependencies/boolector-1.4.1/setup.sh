#!/bin/sh

version=1.4.1
extra_ver=376e6b0-110304

dependencies="picosat-936"

patches_dir=$base_dir/boolector-1.4
cmake_files_dir=$base_dir/boolector-1.4

source $base_dir/boolector-1.4/shared.sh

# vim: te= sw=2 et
