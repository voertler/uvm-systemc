#!/bin/sh

version="3.4"
source $base_dir/libantlr3c-3.4/shared.sh
