#!/bin/sh

version=release

source $base_dir/ninja-release/shared.sh

# vim: ts=2 sw=2 et
