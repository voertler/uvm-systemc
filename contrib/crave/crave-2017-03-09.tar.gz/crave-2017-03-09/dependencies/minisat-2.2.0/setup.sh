#!/bin/sh

version=2.2.0

cmake_files_dir=$base_dir/minisat-2.2.0

source $base_dir/minisat-2.2.0/shared.sh

# vim: ts=2 sw=2 et