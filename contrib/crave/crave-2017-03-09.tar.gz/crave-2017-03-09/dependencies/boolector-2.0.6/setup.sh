#!/bin/sh

version=2.0.6

dependencies="lingeling-ayv-86bf266-140429"

patches_dir=$base_dir/boolector-$version
cmake_files_dir=$base_dir/boolector-$version

source $base_dir/boolector-$version/shared.sh
