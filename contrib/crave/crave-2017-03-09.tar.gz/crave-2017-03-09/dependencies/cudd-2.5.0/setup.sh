#!/bin/sh

version=2.5.0

cmake_files_dir=$base_dir/cudd-2.5.0

source $base_dir/cudd-2.4.2/shared.sh

# vim: ts=2 sw=2 et
