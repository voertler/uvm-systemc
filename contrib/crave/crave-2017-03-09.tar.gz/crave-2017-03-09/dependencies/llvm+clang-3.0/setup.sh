#!/bin/sh

version=3.0

source_llvm="llvm-$version.tar.gz"
source_clang="clang-$version.tar.gz"

source $base_dir/llvm+clang-3.0/shared.sh

# vim: ts=2 sw=2 et