#!/bin/sh

version=2.7.10

source "$base_dir/Python-2.7.10/shared.sh"

# vim: ts=2 sw=2 et
