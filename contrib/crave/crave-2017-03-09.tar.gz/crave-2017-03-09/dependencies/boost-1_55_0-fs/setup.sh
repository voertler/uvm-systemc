#!/bin/sh

version=1_55_0

source "$base_dir/boost-1_55_0-fs/shared.sh"

# vim: ts=2 sw=2 et
