#!/bin/sh

version="2.1.0"

source $base_dir/git-2.1.0/shared.sh
