#!/bin/sh

version=2.0.2
pcre_version=8.30

source $base_dir/swig-2.0.2/shared.sh

# vim: ts=2 sw=2 et
