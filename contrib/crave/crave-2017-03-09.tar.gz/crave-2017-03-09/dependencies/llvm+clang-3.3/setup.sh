#!/bin/sh

version=3.3

source_llvm="llvm-$version.src.tar.gz"
source_clang="cfe-$version.src.tar.gz"

source $base_dir/llvm+clang-3.3/shared.sh

# vim: ts=2 sw=2 et
