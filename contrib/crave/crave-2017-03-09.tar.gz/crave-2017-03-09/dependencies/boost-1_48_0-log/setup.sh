#!/bin/sh

version=1_48_0

source "$base_dir/boost-1_48_0-log/shared-log.sh"

# vim: ts=2 sw=2 et
