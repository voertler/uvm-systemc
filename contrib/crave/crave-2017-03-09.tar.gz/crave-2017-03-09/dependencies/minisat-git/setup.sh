#!/bin/sh

version=git

cmake_files_dir=$base_dir/minisat-2.2.0

source $base_dir/minisat-git/shared-git.sh

# vim: ts=2 sw=2 et
