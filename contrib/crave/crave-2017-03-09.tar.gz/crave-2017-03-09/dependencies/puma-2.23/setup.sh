#!/bin/sh

version=2.23

source $base_dir/puma-2.23/shared.sh

# vim: ts=2 sw=2 et