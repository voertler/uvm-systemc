#!/bin/sh

version=2.18

cmake_config_file="$base_dir/Z3-2.15/Z3Config.cmake"
source "$base_dir/Z3-2.15/shared.sh"

# vim: ts=2 sw=2 et