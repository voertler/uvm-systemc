#!/bin/sh

version=2.4.2

config_files_dir=$base_dir/yices-${version}

source $base_dir/yices-${version}/shared.sh
