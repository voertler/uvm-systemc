#!/bin/sh

version=2.3
branch=master
package=systemc
source=nosourcefile
build_dir=$build/$package-$version
url=https://github.com/systemc/systemc-2.3

source "$base_dir/systemc-2.3/shared.sh"
