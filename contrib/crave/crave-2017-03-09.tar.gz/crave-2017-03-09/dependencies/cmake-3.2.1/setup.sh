#!/bin/sh

version=3.2.1

source $base_dir/cmake-2.8.4/shared.sh

# vim: ts=2 sw=2 et
