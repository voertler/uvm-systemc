#!/bin/sh

version=2.3.0
branch=v2.3.0
package=systemc
source=nosourcefile
build_dir=$build/$package-$version
url=https://github.com/ArchC/SystemC.git

source "$base_dir/systemc-2.3/shared.sh"
