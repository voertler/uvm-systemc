#!/bin/sh

version=20071012

cmake_files_dir=$base_dir/aiger-20071012

source $base_dir/aiger-20071012/shared.sh

# vim: ts=2 sw=2 et