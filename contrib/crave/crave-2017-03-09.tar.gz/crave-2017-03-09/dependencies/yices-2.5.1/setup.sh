#!/bin/sh

version=2.5.1

config_files_dir=$base_dir/yices-2.4.2

source $base_dir/yices-2.4.2/shared.sh
