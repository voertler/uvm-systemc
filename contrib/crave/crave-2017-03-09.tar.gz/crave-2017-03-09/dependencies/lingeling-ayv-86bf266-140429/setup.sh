#!/bin/sh

version=ayv-86bf266-140429

cmake_files_dir=$base_dir/lingeling-${version}

source $base_dir/lingeling-${version}/shared.sh
