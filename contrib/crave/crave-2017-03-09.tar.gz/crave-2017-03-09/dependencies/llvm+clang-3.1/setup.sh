#!/bin/sh

version=3.1

source_llvm="llvm-$version.src.tar.gz"
source_clang="clang-$version.src.tar.gz"

source $base_dir/llvm+clang-3.0/shared.sh

# vim: ts=2 sw=2 et