#!/bin/sh

version=4.4.1
branch=z3-4.4.1

cmake_files_dir=$base_dir/Z3-git

source $base_dir/Z3-git/shared.sh
